// После публикации backend замени URL на HTTPS-адрес своего API (например Render).
window.REVERIE_API = 'https://YOUR-API-HOST';
